import numpy as np

def Accuracy(label, pred):
    ########################################################################################
    # TODO : Complete the code to calculate the accuracy for prediction.
    #         [Input]
    #         - label : (N, ), Correct label with 0 (negative) or 1 (positive)
    #         - hypo  : (N, ), Predicted score between 0 and 1
    #         [output]
    #         - Acc : (scalar, float), Computed accuracy score
    # ========================= EDIT HERE =========================
    Acc = 1.0-np.sum(abs(label-pred))/label.shape
    # =============================================================
    return Acc

def Precision(label, pred):
    ########################################################################################
    # TODO : Complete the code to calculate the Precision for prediction.
    #         you should consider that label = 1 is positive. 0 is negative
    #         Notice that, if you encounter the divide zero, return 1
    #         [Input]
    #         - label : (N, ), Correct label with 0 (negative) or 1 (positive)
    #         - hypo  : (N, ), Predicted score between 0 and 1
    #         [output]
    #         - precision : (scalar, float), Computed precision score
    # ========================= EDIT HERE =========================
    precision = np.sum((label+pred)//2)/np.sum(pred)
    # =============================================================
    return precision

def Recall(label, pred):
    ########################################################################################
    # TODO : Complete the code to calculate the Recall for prediction.
    #         you should consider that label = 1 is positive. 0 is negative
    #         Notice that, if you encounter the divide zero, return 1
    #         [Input]
    #         - label : (N, ), Correct label with 0 (negative) or 1 (positive)
    #         - hypo  : (N, ), Predicted score between 0 and 1
    #         [output]
    #         - recall : (scalar, float), Computed recall score
    # ========================= EDIT HERE =========================
    recall = np.sum((label+pred)//2)/np.sum(label)
    # =============================================================
    return recall

def F_measure(label, pred):
    ########################################################################################
    # TODO : Complete the code to calculate the F-measure score for prediction.
    #         you can erase the code. (F_score = 0.)
    #         Notice that, if you encounter the divide zero, return 1
    #         [Input]
    #         - label : (N, ), Correct label with 0 (negative) or 1 (positive)
    #         - hypo  : (N, ), Predicted score between 0 and 1
    #         [output]
    #         - F_score : (scalar, float), Computed F-score score
    # ========================= EDIT HERE =========================
    precision = np.sum((label+pred)//2)/np.sum(pred)
    recall = np.sum((label+pred)//2)/np.sum(label)
    F_score=2*precision*recall/(precision+recall)
    # =============================================================
    return F_score

def MAP(label, hypo, at = 10):
    ########################################################################################
    # TODO : Complete the code to calculate the MAP for prediction.
    #         Notice that, hypo is the real value array in (0, 1)
    #         MAP (at = 10) means MAP @10
    #         [Input]
    #         - label : (N, K), Correct label with 0 (incorrect) or 1 (correct)
    #         - hypo  : (N, K), Predicted score between 0 and 1
    #         - at: (int), # of element to consider from the first. (TOP-@)
    #         [output]
    #         - Map : (scalar, float), Computed MAP score
    # ========================= EDIT HERE ========================= 
    num=label.shape[1]
    sorted_array = np.zeros((hypo.shape[0], hypo.shape[1]), dtype='f')
    new_label = np.zeros((label.shape[0], label.shape[1]), dtype='i')
    hypo2 = hypo.copy()
    sorted_array = np.sort(hypo2,axis=1)
    for i in range(hypo2.shape[0]):
        sorted_array[i] = sorted_array[i][::-1]
    for i in range(label.shape[0]):
        for j in range(label.shape[1]):
            for k in range(label.shape[1]):
                if(sorted_array[i][j] == hypo2[i][k]):
                    new_label[i][j] = int(label[i][k])
                    hypo2[i][k] = -1
    total = 0.0
    for i in range(hypo2.shape[0]):
        row_sum = np.sum(new_label[i])
        acc = 0.0
        correct = 0
        for j in range(at):
            if(new_label[i][j] == 1):
                correct+=1
                acc+=correct/(j+1)
        total+=acc/row_sum
    Map = total/hypo2.shape[0]
    # =============================================================
    return Map

def nDCG(label, hypo, at = 10):
    ########################################################################################
    # TODO : Complete the each code to calculate the nDCG for prediction.
    #         you can erase the code. (dcg, idcg, ndcg = 0.)
    #         Notice that, hypo is the real value array in (0, 1)
    #         nDCG (at = 10 ) means nDCG @10
    #         [Input]
    #         - label : (N, K), Correct label with 0 (incorrect) or 1 (correct)
    #         - hypo  : (N, K), Predicted score between 0 and 1
    #         - at: (int), # of element to consider from the first. (TOP-@)
    #         [output]
    #         - Map : (scalar, float), Computed nDCG score


    def DCG(label, hypo, at=10):
        # ========================= EDIT HERE =========================
        dcg = np.zeros(hypo.shape[0], dtype='f')
        sorted_array = np.zeros((hypo.shape[0], hypo.shape[1]), dtype='f')
        new_label = np.zeros((label.shape[0], label.shape[1]), dtype='i')
        hypo2 = hypo.copy()
        sorted_array = np.sort(hypo2,axis=1)
        for i in range(hypo2.shape[0]):
            sorted_array[i] = sorted_array[i][::-1]
        for i in range(label.shape[0]):
            for j in range(label.shape[1]):
                for k in range(label.shape[1]):
                    if(sorted_array[i][j] == hypo2[i][k]):
                        new_label[i][j] = int(label[i][k])
                        hypo2[i][k] = -1
        total = 0.0
        for i in range(hypo.shape[0]):
            acc = 0.0
            for j in range(at):
                if(new_label[i][j] == 1):
                    acc+=np.log(2)/np.log(j+2)
            dcg[i]=acc
        # =============================================================
        return dcg

    def IDCG(label, hypo, at=10):
        # ========================= EDIT HERE =========================
        idcg = np.zeros(hypo.shape[0], dtype='f')
        total = 0.0
        for i in range(hypo.shape[0]):
            acc=0.0
#            for j in range(int(np.sum(label[i]))):
            for j in range(min(int(np.sum(label[i])), at)):
                acc+=np.log(2)/np.log(j+2)
            idcg[i]=acc
        # =============================================================
        return idcg
    # ========================= EDIT HERE =========================
    D=DCG(label,hypo,at)
    I=IDCG(label,hypo,at)
    D_Num=D.shape[0]
    temp = 0.0
    for i in range(D_Num):
        temp+=D[i]/I[i]
    ndcg=temp/D_Num
    # =============================================================
    return ndcg

# =============================================================== #
# ===================== DO NOT EDIT BELOW ======================= #
# =============================================================== #

def evaluation_test1(label, pred, at = 10):
    result = {}

    result['Accuracy '] = Accuracy(label, pred)
    result['Precision'] = Precision(label, pred)
    result['Recall   '] = Recall(label, pred)
    result['F_measure'] = F_measure(label, pred)

    return result

def evaluation_test2(label, hypo, at = 10):
    result = {}

    result['MAP  @%d'%at] = MAP(label, hypo, at)
    result['nDCG @%d'%at] = nDCG(label, hypo, at)

    return result
