import numpy as np




"""
  =========================================
|| COPY Codes from the previous assignment ||
  =========================================
"""

class SGD:
    # ========================= EDIT HERE =========================
    def __init__(self, gamma, epsilon):
        pass

    def update(self, w, grad, lr):
        return None
    # =============================================================

class Momentum:
    # ========================= EDIT HERE =========================
    def __init__(self, gamma, epsilon):
        pass

    def update(self, w, grad, lr):
        return None
    # =============================================================

class RMSProp:
    # ========================= EDIT HERE =========================
    def __init__(self, gamma, epsilon):
        pass

    def update(self, w, grad, lr):
        return None
    # =============================================================